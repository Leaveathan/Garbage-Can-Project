#ifndef __LED_H__
#define __LED_H__

#include "sys.h"



//�궨���ʹ�õ�io�˿ڳ�ʼ������
#define Lamplight_GPIO           GPIO_Pin_13
#define Lamplight_GPIO_PORT      GPIOC
#define Lamplight_GPIO_CLK        RCC_APB2Periph_GPIOC


#define WIFI_GPIO_PORT       GPIOA
#define WIFI_GPIO_CLK       RCC_APB2Periph_GPIOA
#define wifi_rst_PIN        GPIO_Pin_1

#define Lamplight_OFF       GPIO_ResetBits(Lamplight_GPIO_PORT, Lamplight_GPIO) //��        
#define Lamplight_ON        GPIO_SetBits(Lamplight_GPIO_PORT, Lamplight_GPIO)      //��

#define WIFI_RST     GPIO_SetBits(WIFI_GPIO_PORT, wifi_rst_PIN) 

void LED_GPIO_Config(void);
void wifi_GPIO_Config(void);

#endif

