#ifndef __BEEP_H
#define	__BEEP_H


#include "sys.h" 


/* ��ض˿����ú� */
#define Buzzer_GPIO_CLK 	    RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define Buzzer_GPIO_PORT    	GPIOA						/* GPIO�˿� */
#define Buzzer_GPIO_PIN		    GPIO_Pin_8					/* ���ӵ�SCLʱ���ߵ�GPIO */








/* �������IO�ĺ� */
#define Buzzer_TOGGLE		    digitalToggle(Buzzer_GPIO_PORT,Buzzer_GPIO_PIN)
#define Buzzer_ON		        digitalHi(Buzzer_GPIO_PORT,Buzzer_GPIO_PIN)
#define Buzzer_OFF			   digitalLo(Buzzer_GPIO_PORT,Buzzer_GPIO_PIN)

void Beep_Init(void);
//void Beep_StateRefresh(uint8_t BeepState); 





#endif 
