#ifndef __RELAY_H__
#define __RELAY_H__

#include "sys.h"

#define RELAY_Fan               GPIO_Pin_12
#define RELAY_Water_Pump        GPIO_Pin_13
#define RELAY_Exhaust_system  GPIO_Pin_14

#define RELAY_GPIO_PORT  GPIOB
#define RELAY_GPIO_CLK  RCC_APB2Periph_GPIOB





#define RELAY_Fan_ON        						GPIO_SetBits(RELAY_GPIO_PORT, RELAY_Fan)         
#define RELAY_Fan_OFF      							GPIO_ResetBits(RELAY_GPIO_PORT, RELAY_Fan)          

#define RELAY_Water_Pump_ON      			  GPIO_SetBits(RELAY_GPIO_PORT, RELAY_Water_Pump)         
#define RELAY_Water_Pump_OFF      			GPIO_ResetBits(RELAY_GPIO_PORT, RELAY_Water_Pump) 

#define RELAY_Exhaust_system_ON       GPIO_SetBits(RELAY_GPIO_PORT, RELAY_Exhaust_system)         
#define RELAY_Exhaust_system_OFF      GPIO_ResetBits(RELAY_GPIO_PORT, RELAY_Exhaust_system) 

void RELAY_GPIO_Config(void);


#endif

