
#include "sys.h"



#define SG90_GPIO_PIN   GPIO_Pin_15
#define SG90_GPIO_PORT  GPIOB
#define SG90_GPIO_CLK  RCC_APB2Periph_GPIOB

void SG90_Init(void);
void Control_SG901(uint32_t us);
void Control_SG902(uint32_t us);
void Control_SG903(uint32_t us);
void Control_SG904(uint32_t us);


