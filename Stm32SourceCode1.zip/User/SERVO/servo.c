#include "sys.h"

void SG90_Init(void)
{
	GPIO_InitTypeDef temp;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	temp.GPIO_Mode=GPIO_Mode_Out_PP;
	temp.GPIO_Pin=GPIO_Pin_15|GPIO_Pin_14|GPIO_Pin_13|GPIO_Pin_12;
	temp.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&temp);

}



/*���������Ӧת�����ٽǶ�   500us��Ӧ0��

											500us,0�
											1000us,45�
											1500us,90�
											2000us,145�
											2500us,180�
					  
*/
void Control_SG901(uint32_t us)
{
		
	int i=0;
	for(i=0;i<10;i++)
	{
		if(us<=20000)
		{
			PBout(12)=1;
			delay_us(us);
			PBout(12)=0;
			delay_us(20000-us);
		}
	}

}



void Control_SG902(uint32_t us)
{
		
	int i=0;
	for(i=0;i<10;i++)
	{
		if(us<=20000)
		{
			PBout(13)=1;
			delay_us(us);
			PBout(13)=0;
			delay_us(20000-us);
		}
	}

}


void Control_SG903(uint32_t us)
{
		
	int i=0;
	for(i=0;i<10;i++)
	{
		if(us<=20000)
		{
			PBout(14)=1;
			delay_us(us);
			PBout(14)=0;
			delay_us(20000-us);
		}
	}

}


void Control_SG904(uint32_t us)
{
		
	int i=0;
	for(i=0;i<10;i++)
	{
		if(us<=20000)
		{
			PBout(15)=1;
			delay_us(us);
			PBout(15)=0;
			delay_us(20000-us);
		}
	}

}
