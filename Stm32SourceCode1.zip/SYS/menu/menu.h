#ifndef __MENU_H
#define __MENU_H
#include "sys.h"

extern int16_t Servo_Speed;
extern uint8_t OperateMode;
extern uint8_t SwitchFlag1, SwitchFlag2, SwitchFlag3, SwitchFlag4;
extern uint8_t IndexFlag1;//ѡ������
extern uint8_t CursorFlag1;//�������
extern uint8_t IndexFlag;//ѡ������
extern uint8_t CursorFlag;//�������
void Inform_Show(void) ;
void Inform_Show2(void) ;
void Mode_Decide(void);//ģʽ�ж�
void AutoContrl(void);
void Manual_Contrl(void);
void ThresholdSet(void);
void ThresholdSet1(void);
void SeasonSet(void);
void Anti_theft_mode(void);
void Manual_Mode(void);
void beep_led_staterefresh(void);
//void Threshold_Init(THRESHOLD *Threshold);
#endif

