#include "sys.h" 
uint8_t OperateMode = 0; //����ģʽ��־λ
uint8_t IndexFlag1 = 1; //ѡ������
uint8_t CursorFlag1 = 1; //�������
uint8_t IndexFlag = 1; //ѡ������
uint8_t CursorFlag = 1; //�������
uint8_t start;
/******************
���ܣ�ģʽѡ�񼰿��ƽ���
��������
����ֵ����
******************/
void Mode_Decide(void)//ģʽ�ж�
{
  Inform_Show();
//	Manual_Contrl();
	Manual_Mode();
}

/******************
���ܣ���ʾ����
��������
����ֵ����
******************/
void Inform_Show(void)
{
oled_ShowCHinese(16*0,2*0,0);
oled_ShowCHinese(16*1,2*0,1);
oled_ShowCHinese(16*2,2*0,2);
oled_ShowCHinese(16*3,2*0,3);
oled_ShowString(16*4,2*0,":",16);

	
oled_ShowCHinese(16*0,2*1,4);
oled_ShowCHinese(16*1,2*1,5);
oled_ShowCHinese(16*2,2*1,6);
oled_ShowCHinese(16*3,2*1,7);
oled_ShowString(16*4,2*1,":",16);	

	
oled_ShowCHinese(16*0,2*2,8);
oled_ShowCHinese(16*1,2*2,9);
oled_ShowCHinese(16*2,2*2,10);
oled_ShowCHinese(16*3,2*2,11);
oled_ShowString(16*4,2*2,":",16);	
	

oled_ShowCHinese(16*0,2*3,12);
oled_ShowCHinese(16*1,2*3,13);
oled_ShowCHinese(16*2,2*3,14);
oled_ShowCHinese(16*3,2*3,15);
oled_ShowString(16*4,2*3,":",16);

if(SensorData.Sensor1==0){
oled_ShowCHinese(16*6,2*0,16);
oled_ShowCHinese(16*7,2*0,17);	
}else{
oled_ShowCHinese(16*6,2*0,18);
oled_ShowCHinese(16*7,2*0,19);	
}



if(SensorData.Sensor2==0){
oled_ShowCHinese(16*6,2*1,16);
oled_ShowCHinese(16*7,2*1,17);	
}else{
oled_ShowCHinese(16*6,2*1,18);
oled_ShowCHinese(16*7,2*1,19);	
}


if(SensorData.Sensor3==0){
oled_ShowCHinese(16*6,2*2,16);
oled_ShowCHinese(16*7,2*2,17);	
}else{
oled_ShowCHinese(16*6,2*2,18);
oled_ShowCHinese(16*7,2*2,19);	
}


if(SensorData.Sensor4==0){
oled_ShowCHinese(16*6,2*3,16);
oled_ShowCHinese(16*7,2*3,17);	
}else{
oled_ShowCHinese(16*6,2*3,18);
oled_ShowCHinese(16*7,2*3,19);	
}

if(SensorData.Sensor5>40){
System.Execute5=1;
}else{
System.Execute5=0;
}

}


/******************
���ܣ��Զ�����
��������
����ֵ����
******************/

void AutoContrl(void)
{






    //5 ���ⱨ����������



}











/******************
���ܣ��ֶ����ƽ���
��������
����ֵ����
******************/
void Manual_Contrl(void)
{

if(isKey1){
System.Execute1=1;
isKey1=0;	
}

if(isKey2){
System.Execute2=1;
isKey2=0;	
}
if(isKey3){
System.Execute3=1;
isKey3=0;	
}

if(isKey4){
System.Execute4=1;
isKey4=0;	
}


}




void Manual_Mode()
{
if(SensorData.Sensor1==1){
if(System.Execute1==1)   {Control_SG901(1000);System.Execute1=2;}
}

if(System.Execute1==0)   {Control_SG901(500);System.Execute1=3;}

if(SensorData.Sensor1==0&&System.Execute1 !=4 ){Control_SG901(500);System.Execute1=4;}


if(SensorData.Sensor2==1){
if(System.Execute2==1)  {Control_SG902(1000);System.Execute2=2;}
}
if(System.Execute2==0)  {Control_SG902(500);	System.Execute2=3;}
if(SensorData.Sensor2==0&&System.Execute2 !=4){Control_SG902(500);	System.Execute2=3;}



if(SensorData.Sensor3==1){
if(System.Execute3==1) { Control_SG903(1000);System.Execute3=2;}
}
if(System.Execute3==0)   { Control_SG903(500);	System.Execute3=3;}
if(SensorData.Sensor3==0&&System.Execute3 !=4){ Control_SG903(500);	System.Execute3=3;}	



if(SensorData.Sensor4==1){
if(System.Execute4==1)  {Control_SG904(1000);System.Execute4=2;}
}
if(System.Execute4==0)   { Control_SG904(500);	System.Execute4=3;}
if(SensorData.Sensor4==0&&System.Execute4 !=4){Control_SG904(500);	System.Execute4=3;}	



if(System.Execute5==1)   {Buzzer_ON;}
else   {Buzzer_OFF;	}
}

//void beep_led_staterefresh(void)
//{
//    start++;

//    if (start >=1) {
//       System.Execute5 = 1;
//        start = 0;
//    } else {
//        System.Execute5 = 0;
//    }
//}
