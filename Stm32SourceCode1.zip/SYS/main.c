#include "sys.h"
//#include "usart3.h"
SENSOR SensorData;

SYSTEM System;

void Public(void);


int main(void)
{
	
    delay_init();

 
    NVIC_Config(); 
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    My_USART1();//Serial port settings Baud rate 9600

	  Usart3_Init(9600);

    TIM1_Int_Init(10000-1,7200-1);

    Beep_Init();//a series of initialisations
    Adc_Init();
	  DO_Init();
    LED_GPIO_Config();//LED
	   SG90_Init();
    oled_Init();//oled

     TIM2_Init(5000,7199);
	    oled_Clear();
//     oled_ShowString(0,2,"Connecting...",16);
    /*******************************************/
    while (1) {
        

		
      
        SensorData.Sensor1 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4);
        SensorData.Sensor2 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_5);
			  SensorData.Sensor3 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_6);
			  SensorData.Sensor4 = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_7);
			  SensorData.Sensor5 = Get_Adc_Average(0,10)/41;
    

        Mode_Decide();

    }
}


void Public(void)
{
	u1_printf("A:%d#,B:%d#,C:%d#,D:%d#",SensorData.Sensor1,SensorData.Sensor2,SensorData.Sensor3,SensorData.Sensor4);
}




